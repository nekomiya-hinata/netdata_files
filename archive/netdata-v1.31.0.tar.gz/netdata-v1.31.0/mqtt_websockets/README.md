# mqtt_websockets

Library to connect MQTT client over Websockets Secure (WSS).
Documentation is pending. Best way to figure out how to use the library it to look at `src\test.c`.

## License

The Project is released under GPL v3 license. See [License](LICENSE)

## Credits

Uses following git submodules:
- **MQTT-C**: released under MIT license. Original Authors **Liam Bindle**, **Demilade Adeoye**. Using custom fork with additional functionality not present yet in upstream.
- **c-rbuf**: under LGPL 3 by myself