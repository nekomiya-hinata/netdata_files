# Do not edit any files in this directory!

If you spot any errors or bugs in these files and wish to fix them, please submit your changes at
https://github.com/netdata/dashboard instead.

These files are copied from the most recent release of that repository, and any changes you make here will be
overwritten the next time there’s a new release there.
